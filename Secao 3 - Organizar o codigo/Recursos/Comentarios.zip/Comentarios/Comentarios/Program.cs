﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comentarios
{
    class Program
    {
        // Metodo principal
        // Outra linha
        static void Main(string[] args)
        {
            #region Primeiro Bloco
            /*
             Este é um bloco de comentario
             Posso inserir varias linhas
             E ainda outra linha
            */
            #endregion

            #region Primeira parte
            //Console.WriteLine("Ola Mundo !");
            //Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            #endregion

            #region Segunda parte
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            Console.WriteLine("Ola Mundo !");
            #endregion


            Console.ReadKey();
        }
    }
}
